package com.example.medtracker.ui

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.lifecycle.lifecycleScope
import com.example.medtracker.data.*
import com.itextpdf.text.Document
import com.itextpdf.text.Font
import com.itextpdf.text.Paragraph
import com.itextpdf.text.pdf.PdfWriter
import android.util.Base64
import com.example.medtracker.ui.MainActivity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*

/**
 * Activity for generating consumption reports. Users can select a date
 * range and optionally filter by a specific medication. The application
 * calculates total dose amounts and the status (taken, skipped, snoozed)
 * within the selected period. A PDF report can be generated with or
 * without password protection. Password protection uses the current
 * master password and salt to encrypt the PDF via iText. The report can
 * then be exported through an Android share sheet or saved locally.
 */
class ReportActivity : ComponentActivity() {
    private lateinit var repository: MedicationRepository
    private lateinit var medList: List<Medication>
    private var selectedMedId: Long? = null
    private var startDate: Long = 0L
    private var endDate: Long = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val keyBytes = intent.getByteArrayExtra(HomeActivity.EXTRA_DB_KEY) ?: ByteArray(0)
        val db = AppDatabase.getInstance(applicationContext, keyBytes)
        repository = MedicationRepository(db)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 32, 32, 32)
        }
        val title = TextView(this).apply {
            text = "Generate Report"
            textSize = 24f
            gravity = Gravity.CENTER_HORIZONTAL
        }
        root.addView(title)

        // Medication filter spinner
        val medSpinner = Spinner(this)
        root.addView(TextView(this).apply { text = "Medication (optional)" })
        root.addView(medSpinner)

        // Date range pickers
        val startButton = Button(this).apply { text = "Start Date" }
        val endButton = Button(this).apply { text = "End Date" }
        root.addView(startButton)
        root.addView(endButton)

        startButton.setOnClickListener { pickDate { millis ->
            startDate = millis
            val format = SimpleDateFormat("yyyy-MM-dd", Locale.US)
            startButton.text = "Start: ${format.format(Date(millis))}"
        } }
        endButton.setOnClickListener { pickDate { millis ->
            endDate = millis
            val format = SimpleDateFormat("yyyy-MM-dd", Locale.US)
            endButton.text = "End: ${format.format(Date(millis))}"
        } }

        // Generate report button
        val generateButton = Button(this).apply { text = "Generate PDF" }
        root.addView(generateButton)

        generateButton.setOnClickListener {
            lifecycleScope.launch {
                generateReport(startDate, endDate, selectedMedId)
            }
        }

        setContentView(root)

        // Load medications
        lifecycleScope.launch {
            repository.getMedications().collect { meds ->
                medList = meds
                val names = listOf("All") + meds.map { it.name }
                medSpinner.adapter = ArrayAdapter(this@ReportActivity, android.R.layout.simple_spinner_dropdown_item, names)
                medSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                    override fun onItemSelected(parent: AdapterView<*>, view: View?, position: Int, id: Long) {
                        selectedMedId = if (position == 0) null else meds[position - 1].id
                    }
                    override fun onNothingSelected(parent: AdapterView<*>) {
                        selectedMedId = null
                    }
                }
            }
        }
    }

    /**
     * Shows a date picker and passes the selected date in milliseconds to
     * [onResult]. The time component is truncated so only the date matters.
     */
    private fun pickDate(onResult: (Long) -> Unit) {
        val cal = Calendar.getInstance()
        android.app.DatePickerDialog(this, { _, year, month, dayOfMonth ->
            cal.set(year, month, dayOfMonth, 0, 0, 0)
            onResult(cal.timeInMillis)
        }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
    }

    /**
     * Generates a PDF report summarising consumption between [start] and [end]
     * milliseconds. If [medId] is provided, the report focuses on that
     * medication; otherwise all medications are included. The PDF is written
     * to a temporary file. When complete, the user is offered to share or
     * view the PDF via an implicit intent. If the user has opted for
     * password protection, the PDF is encrypted with the current master
     * password and salt.
     */
    private suspend fun generateReport(start: Long, end: Long, medId: Long?) {
        withContext(Dispatchers.IO) {
            // Ensure start and end dates are valid. If end is zero, default to now.
            val startTime = if (start > 0L) start else 0L
            val endTime = if (end > 0L) end else System.currentTimeMillis()
            // Retrieve doses in the given range. If medId is null, all meds are included.
            val doseList = repository.getDosesBetween(startTime, endTime, medId)
            // Build a stats map keyed by medicationId
            data class Stats(var totalAmountGrams: Double = 0.0, var takenCount: Int = 0, var skippedCount: Int = 0, var snoozedCount: Int = 0)
            val statsMap = mutableMapOf<Long, Stats>()
            for (dose in doseList) {
                val stats = statsMap.getOrPut(dose.medicationId) { Stats() }
                // Convert dose amount to grams using multiplier
                val grams = dose.amount * dose.unit.multiplier
                stats.totalAmountGrams += grams
                when (dose.status) {
                    DoseStatus.TAKEN -> stats.takenCount++
                    DoseStatus.SKIPPED -> stats.skippedCount++
                    DoseStatus.SNOOZED -> stats.snoozedCount++
                    else -> {}
                }
            }
            // Prepare PDF file
            val file = File(cacheDir, "report_${System.currentTimeMillis()}.pdf")
            val doc = Document()
            val fos = FileOutputStream(file)
            val writer = PdfWriter.getInstance(doc, fos)
            // Determine if PDF should be encrypted based on settings. When
            // enabled, use the stored database encryption key as the user
            // password. Owner password is left blank. Standard 128‑bit
            // encryption restricts printing only.
            val securePrefs = MainActivity.getSecurePrefs(this@ReportActivity)
            val encryptPdf = securePrefs.getBoolean("pref_pdf_encrypt", true)
            if (encryptPdf) {
                val keyBase64 = securePrefs.getString("db_key", null)
                if (keyBase64 != null) {
                    val keyBytes = android.util.Base64.decode(keyBase64, android.util.Base64.NO_WRAP)
                    writer.setEncryption(
                        keyBytes,
                        null,
                        PdfWriter.ALLOW_PRINTING,
                        PdfWriter.ENCRYPTION_AES_128
                    )
                }
            }
            doc.open()
            val titleFont = Font(Font.FontFamily.HELVETICA, 18f, Font.BOLD)
            val normalFont = Font(Font.FontFamily.HELVETICA, 12f, Font.NORMAL)
            doc.add(Paragraph("Medication Report", titleFont))
            doc.add(Paragraph("Date Range: ${Date(startTime)} - ${Date(endTime)}", normalFont))
            doc.add(Paragraph("\n"))
            // Write stats per medication
            for ((medIdKey, stats) in statsMap) {
                val medName = medList.firstOrNull { it.id == medIdKey }?.name ?: "Unknown"
                doc.add(Paragraph("Medication: $medName", Font(Font.FontFamily.HELVETICA, 14f, Font.BOLD)))
                doc.add(Paragraph("Total amount: ${"%.3f".format(stats.totalAmountGrams)} g", normalFont))
                doc.add(Paragraph("Taken: ${stats.takenCount}", normalFont))
                doc.add(Paragraph("Skipped: ${stats.skippedCount}", normalFont))
                doc.add(Paragraph("Snoozed: ${stats.snoozedCount}", normalFont))
                doc.add(Paragraph("\n"))
            }
            doc.close()
            fos.close()
            // Launch share intent on main thread
            withContext(Dispatchers.Main) {
                val uri = androidx.core.content.FileProvider.getUriForFile(
                    this@ReportActivity,
                    "com.example.medtracker.fileprovider",
                    file
                )
                val viewIntent = Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(uri, "application/pdf")
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                startActivity(Intent.createChooser(viewIntent, "Open report with"))
            }
        }
    }
}