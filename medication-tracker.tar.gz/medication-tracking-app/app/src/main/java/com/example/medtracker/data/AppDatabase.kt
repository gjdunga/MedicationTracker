package com.example.medtracker.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportFactory
import net.sqlcipher.database.SQLiteDatabase

/**
 * Central entry point for Room. This database includes all of the entities
 * used by the application. To ensure confidentiality, we always supply a
 * cipher key to Room's SQLCipher SupportFactory when constructing the
 * database. The key must be derived using the user's password and a
 * unique salt via PBKDF2, as implemented in [KeyManager].
 */
@Database(
    entities = [Medication::class, Dose::class, MedicationLog::class],
    version = 1,
    exportSchema = false
)
@androidx.room.TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun medicationDao(): MedicationDao
    abstract fun doseDao(): DoseDao
    abstract fun logDao(): MedicationLogDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        /**
         * Returns a singleton instance of the database. This method must be
         * called after the user has authenticated and a key has been
         * derived. Passing an empty or incorrect key will fail to open the
         * encrypted database. To avoid returning null, we throw an
         * IllegalStateException if no key is provided.
         */
        fun getInstance(context: Context, passphrase: ByteArray): AppDatabase {
            // Always ensure the SQLCipher provider is initialized
            SQLiteDatabase.loadLibs(context)
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: buildDatabase(context, passphrase).also { INSTANCE = it }
            }
        }

        private fun buildDatabase(context: Context, passphrase: ByteArray): AppDatabase {
            require(passphrase.isNotEmpty()) { "Encryption passphrase must not be empty" }
            val factory = SupportFactory(passphrase)
            return Room.databaseBuilder(
                context.applicationContext,
                AppDatabase::class.java,
                "medication.db"
            )
                .openHelperFactory(factory)
                .fallbackToDestructiveMigration()
                .build()
        }
    }
}