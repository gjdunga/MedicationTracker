package com.example.medtracker.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.medtracker.data.AppDatabase
import com.example.medtracker.data.Dose
import com.example.medtracker.data.DoseUnit
import com.example.medtracker.data.Medication
import com.example.medtracker.data.MedicationRepository
import com.example.medtracker.network.NetworkModule
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Main screen displayed after the user successfully unlocks the application.
 * Presents a list of medications and actions to add, modify, or generate
 * reports. This simplified implementation focuses on medication CRUD
 * operations and demonstrates how to interact with the repository. Alarm
 * scheduling, report generation, export/import, and other advanced features
 * would be implemented in additional activities or fragments.
 */
class HomeActivity : ComponentActivity() {
    private lateinit var repository: MedicationRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Retrieve the encryption key passed from MainActivity
        val keyBytes = intent.getByteArrayExtra(EXTRA_DB_KEY) ?: ByteArray(0)
        val db = AppDatabase.getInstance(applicationContext, keyBytes)
        repository = MedicationRepository(db)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 16, 16, 16)
        }
        val title = TextView(this).apply {
            text = "Your Medications"
            textSize = 24f
            gravity = Gravity.CENTER_HORIZONTAL
        }
        val recyclerView = RecyclerView(this).apply {
            layoutManager = LinearLayoutManager(this@HomeActivity)
            adapter = MedicationAdapter()
        }
        val addMedButton = Button(this).apply {
            text = "Add Medication"
            setOnClickListener { showAddMedicationDialog() }
        }
        val addDoseButton = Button(this).apply {
            text = "Add Dose"
            setOnClickListener {
                // Launch AddDoseActivity with the encryption key
                val intent = Intent(this@HomeActivity, AddDoseActivity::class.java)
                intent.putExtra(EXTRA_DB_KEY, keyBytes)
                startActivity(intent)
            }
        }
        val reportButton = Button(this).apply {
            text = "Reports"
            setOnClickListener {
                val intent = Intent(this@HomeActivity, ReportActivity::class.java)
                intent.putExtra(EXTRA_DB_KEY, keyBytes)
                startActivity(intent)
            }
        }
        val settingsButton = Button(this).apply {
            text = "Settings"
            setOnClickListener {
                val intent = Intent(this@HomeActivity, SettingsActivity::class.java)
                startActivity(intent)
            }
        }
        root.addView(title)
        root.addView(recyclerView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(addMedButton)
        root.addView(addDoseButton)
        root.addView(reportButton)
        root.addView(settingsButton)
        setContentView(root)

        // Observe medications and update adapter
        lifecycleScope.launch {
            repository.getMedications().collect { meds ->
                (recyclerView.adapter as MedicationAdapter).submitList(meds)
            }
        }
    }

    /**
     * Shows a dialog prompting the user for a medication name. The name is
     * looked up against RxNorm to obtain spelling suggestions. The first
     * suggestion is displayed to the user and used if they accept. The
     * medication is saved to the database through the repository.
     */
    private fun showAddMedicationDialog() {
        val dialogLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 32, 32, 32)
        }
        val nameField = EditText(this).apply {
            hint = "Medication name"
        }
        val suggestionView = TextView(this).apply {
            visibility = View.GONE
        }
        val okButton = Button(this).apply { text = "Add" }
        val cancelButton = Button(this).apply { text = "Cancel" }
        dialogLayout.addView(nameField)
        dialogLayout.addView(suggestionView)
        dialogLayout.addView(okButton)
        dialogLayout.addView(cancelButton)

        val dialog = android.app.AlertDialog.Builder(this)
            .setTitle("Add Medication")
            .setView(dialogLayout)
            .create()
        cancelButton.setOnClickListener { dialog.dismiss() }
        okButton.setOnClickListener {
            val nameInput = nameField.text.toString().trim()
            if (nameInput.isNotBlank()) {
                // Launch coroutine to fetch spelling suggestions
                lifecycleScope.launch {
                    val service = NetworkModule.rxNormService
                    try {
                        val response = withContext(Dispatchers.IO) {
                            service.getSpellingSuggestions(nameInput)
                        }
                        val suggestion = response.suggestionGroup?.suggestionList?.suggestions?.firstOrNull()
                        val finalName = suggestion ?: nameInput
                        repository.addMedication(Medication(name = finalName))
                    } catch (ex: Exception) {
                        // Fallback to original input if network call fails
                        repository.addMedication(Medication(name = nameInput))
                    }
                }
            }
            dialog.dismiss()
        }
        dialog.show()
    }

    /**
     * RecyclerView adapter for displaying a list of medications. For brevity
     * this adapter uses a simple TextView for each item and does not handle
     * click events or nested dose lists. In a production app you would
     * implement view holders and separate item layouts.
     */
    private inner class MedicationAdapter : RecyclerView.Adapter<MedicationAdapter.ViewHolder>() {
        private var items: List<Medication> = emptyList()

        inner class ViewHolder(val textView: TextView) : RecyclerView.ViewHolder(textView)

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
            val tv = TextView(parent.context).apply {
                textSize = 18f
                setPadding(8, 16, 8, 16)
            }
            return ViewHolder(tv)
        }

        override fun getItemCount(): Int = items.size

        override fun onBindViewHolder(holder: ViewHolder, position: Int) {
            val med = items[position]
            holder.textView.text = med.name
        }

        fun submitList(list: List<Medication>) {
            items = list
            notifyDataSetChanged()
        }
    }

    companion object {
        const val EXTRA_DB_KEY = "extra_db_key"
    }
}