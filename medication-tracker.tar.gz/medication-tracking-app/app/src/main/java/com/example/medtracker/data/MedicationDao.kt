package com.example.medtracker.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

/**
 * Data access object for [Medication]. DAO functions return reactive
 * flows to allow the UI to observe changes without dealing with null
 * references. Kotlin's Flow emits lists of Medication objects that are
 * never null, satisfying the no‑null requirement.
 */
@Dao
interface MedicationDao {
    @Query("SELECT * FROM medications ORDER BY name ASC")
    fun getAllMedications(): Flow<List<Medication>>

    @Query("SELECT * FROM medications WHERE id = :id")
    suspend fun getMedicationById(id: Long): Medication

    @Query("SELECT * FROM medications WHERE name LIKE :pattern ORDER BY name ASC")
    fun searchMedications(pattern: String): Flow<List<Medication>>

    @Insert
    suspend fun insert(medication: Medication): Long

    @Update
    suspend fun update(medication: Medication)

    @Delete
    suspend fun delete(medication: Medication)
}