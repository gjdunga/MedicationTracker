package com.example.medtracker.network

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass
import retrofit2.http.GET
import retrofit2.http.Query

/**
 * Defines the RxNorm API endpoint for spelling suggestions. The National
 * Library of Medicine provides this service to obtain drug names and
 * suggestions for misspelled terms【607347052983884†L85-L90】. This interface uses
 * Retrofit and Moshi for JSON parsing.
 */
interface RxNormService {
    @GET("REST/spellingsuggestions.json")
    suspend fun getSpellingSuggestions(@Query("name") name: String): SpellingResponse
}

/**
 * Response container for the RxNorm spelling suggestion API. The JSON
 * structure nests the suggestion list within several layers, so we map
 * accordingly. Fields not used by the application are omitted for brevity.
 */
@JsonClass(generateAdapter = true)
data class SpellingResponse(
    @Json(name = "suggestionGroup") val suggestionGroup: SuggestionGroup? = null
)

@JsonClass(generateAdapter = true)
data class SuggestionGroup(
    @Json(name = "suggestionList") val suggestionList: SuggestionList? = null
)

@JsonClass(generateAdapter = true)
data class SuggestionList(
    @Json(name = "suggestion") val suggestions: List<String> = emptyList()
)