package com.example.medtracker.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Represents a medication entry. Each medication has a unique identifier
 * and a display name. The optional rxCui field stores the RxNorm concept
 * identifier returned by the external API when available. Storing this
 * identifier allows the application to fetch standardized drug details and
 * ensure accurate spelling without retaining the raw API response.
 */
@Entity(tableName = "medications")
data class Medication(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val name: String,
    val rxCui: String = ""
)