package com.example.medtracker.network

import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory

/**
 * Provides singleton instances of Retrofit and RxNormService. The base URL
 * points to the RxNav API host. Since this is a simple data service
 * without authentication, no interceptors are configured. If additional
 * endpoints are added or API keys become necessary, they should be
 * injected here.
 */
object NetworkModule {
    private const val BASE_URL = "https://rxnav.nlm.nih.gov/"

    private val moshi: Moshi = Moshi.Builder()
        .add(KotlinJsonAdapterFactory())
        .build()

    private val retrofit: Retrofit = Retrofit.Builder()
        .baseUrl(BASE_URL)
        .addConverterFactory(MoshiConverterFactory.create(moshi))
        .build()

    val rxNormService: RxNormService by lazy {
        retrofit.create(RxNormService::class.java)
    }
}