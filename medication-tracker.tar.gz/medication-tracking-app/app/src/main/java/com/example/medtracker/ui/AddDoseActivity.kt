package com.example.medtracker.ui

import android.app.AlarmManager
import android.app.DatePickerDialog
import android.app.PendingIntent
import android.app.TimePickerDialog
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.lifecycle.lifecycleScope
import com.example.medtracker.alarms.DoseAlarmReceiver
import com.example.medtracker.data.*
import kotlinx.coroutines.launch
import java.util.*

/**
 * Activity that allows the user to schedule a new dose for an existing medication. A
 * spinner lists current medications and units (g, mg, µg). The user selects the
 * amount and chooses a date and time for the dose. Upon saving, the dose is
 * inserted into the database through the repository and an alarm is scheduled
 * using [AlarmManager] to trigger the notification at the selected time. This
 * component avoids nullable references by supplying sensible defaults for UI
 * fields.
 */
class AddDoseActivity : ComponentActivity() {
    private lateinit var repository: MedicationRepository
    private lateinit var medList: List<Medication>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val keyBytes = intent.getByteArrayExtra(HomeActivity.EXTRA_DB_KEY) ?: ByteArray(0)
        val db = AppDatabase.getInstance(applicationContext, keyBytes)
        repository = MedicationRepository(db)

        // Root layout
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 32, 32, 32)
        }

        val title = TextView(this).apply {
            text = "Schedule Dose"
            textSize = 24f
            gravity = Gravity.CENTER_HORIZONTAL
        }
        root.addView(title)

        // Medication spinner
        val medSpinner = Spinner(this)
        root.addView(TextView(this).apply { text = "Medication" })
        root.addView(medSpinner)

        // Amount entry
        val amountField = EditText(this).apply {
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
            hint = "Amount"
        }
        root.addView(TextView(this).apply { text = "Amount" })
        root.addView(amountField)

        // Unit spinner
        val unitSpinner = Spinner(this)
        val units = DoseUnit.values().map { it.name }
        val unitAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, units)
        unitSpinner.adapter = unitAdapter
        root.addView(TextView(this).apply { text = "Unit" })
        root.addView(unitSpinner)

        // Date and time pickers
        val dateButton = Button(this).apply { text = "Select Date" }
        val timeButton = Button(this).apply { text = "Select Time" }
        root.addView(dateButton)
        root.addView(timeButton)

        var selectedTime = Calendar.getInstance()
        dateButton.setOnClickListener {
            val now = Calendar.getInstance()
            DatePickerDialog(this, { _, year, month, dayOfMonth ->
                selectedTime.set(Calendar.YEAR, year)
                selectedTime.set(Calendar.MONTH, month)
                selectedTime.set(Calendar.DAY_OF_MONTH, dayOfMonth)
                dateButton.text = String.format("%04d-%02d-%02d", year, month + 1, dayOfMonth)
            }, now.get(Calendar.YEAR), now.get(Calendar.MONTH), now.get(Calendar.DAY_OF_MONTH)).show()
        }
        timeButton.setOnClickListener {
            val now = Calendar.getInstance()
            TimePickerDialog(this, { _, hourOfDay, minute ->
                selectedTime.set(Calendar.HOUR_OF_DAY, hourOfDay)
                selectedTime.set(Calendar.MINUTE, minute)
                selectedTime.set(Calendar.SECOND, 0)
                timeButton.text = String.format("%02d:%02d", hourOfDay, minute)
            }, now.get(Calendar.HOUR_OF_DAY), now.get(Calendar.MINUTE), true).show()
        }

        // Save button
        val saveButton = Button(this).apply { text = "Save" }
        root.addView(saveButton)
        saveButton.setOnClickListener {
            val amountStr = amountField.text.toString().trim()
            if (amountStr.isNotBlank() && medList.isNotEmpty()) {
                val amount = amountStr.toDouble()
                val unit = DoseUnit.valueOf(unitSpinner.selectedItem as String)
                val med = medList[medSpinner.selectedItemPosition]
                val scheduled = selectedTime.timeInMillis
                lifecycleScope.launch {
                    val dose = Dose(
                        medicationId = med.id,
                        amount = amount,
                        unit = unit,
                        scheduledTime = scheduled,
                        status = DoseStatus.SCHEDULED
                    )
                    val newId = repository.addDoseAndReturnId(dose)
                    scheduleAlarm(newId, scheduled)
                    finish()
                }
            } else {
                Toast.makeText(this, "Please enter a valid amount", Toast.LENGTH_SHORT).show()
            }
        }

        setContentView(root)

        // Load medications asynchronously
        lifecycleScope.launch {
            repository.getMedications().collect { meds ->
                medList = meds
                val names = meds.map { it.name }
                medSpinner.adapter = ArrayAdapter(this@AddDoseActivity, android.R.layout.simple_spinner_dropdown_item, names)
            }
        }
    }

    /**
     * Schedules an exact alarm via [AlarmManager] for the given dose ID at
     * [triggerAtMillis]. The pending intent includes the dose ID so the
     * [DoseAlarmReceiver] can look up the dose and present the correct
     * notification. If the alarm service is not available the function
     * gracefully no-ops.
     */
    private fun scheduleAlarm(doseId: Long, triggerAtMillis: Long) {
        val alarmMgr = getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val intent = Intent(this, DoseAlarmReceiver::class.java).apply {
            action = DoseAlarmReceiver.ACTION_TRIGGER
            putExtra(DoseAlarmReceiver.EXTRA_DOSE_ID, doseId)
        }
        val pending = PendingIntent.getBroadcast(
            this,
            doseId.toInt(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        alarmMgr.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, pending)
    }
}