package com.example.medtracker.data

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * Represents an individual dosing schedule for a medication. A dose is
 * associated with a medication via the medicationId field and records
 * the amount, unit, scheduled time and current status. Since nullable
 * timestamps can violate the "no null references" requirement, times are
 * represented by millisecond values (epoch). A value of 0 indicates that
 * the dose has not yet been taken. If the dose is skipped, the takenTime
 * remains zero and the status will be SKIPPED. If the user snoozes a dose,
 * the snoozedUntil field records the next time the alarm should ring.
 */
@Entity(
    tableName = "doses",
    foreignKeys = [
        ForeignKey(
            entity = Medication::class,
            parentColumns = ["id"],
            childColumns = ["medicationId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["medicationId"])]
)
data class Dose(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val medicationId: Long,
    val amount: Double,
    val unit: DoseUnit,
    val scheduledTime: Long,
    val status: DoseStatus = DoseStatus.SCHEDULED,
    val takenTime: Long = 0L,
    val snoozedUntil: Long = 0L
)