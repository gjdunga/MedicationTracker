package com.example.medtracker.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

/**
 * Data access object for [Dose]. Provides queries for upcoming doses,
 * doses by medication, and updates to status fields. All flows emit
 * non‑null lists to avoid null values.
 */
@Dao
interface DoseDao {
    @Query("SELECT * FROM doses ORDER BY scheduledTime ASC")
    fun getAllDoses(): Flow<List<Dose>>

    @Query("SELECT * FROM doses WHERE medicationId = :medId ORDER BY scheduledTime ASC")
    fun getDosesForMedication(medId: Long): Flow<List<Dose>>

    @Query("SELECT * FROM doses WHERE status = :status ORDER BY scheduledTime ASC")
    fun getDosesByStatus(status: DoseStatus): Flow<List<Dose>>

    @Query("SELECT * FROM doses WHERE id = :id")
    suspend fun getDoseById(id: Long): Dose

    @Insert
    suspend fun insert(dose: Dose): Long

    @Update
    suspend fun update(dose: Dose)

    @Delete
    suspend fun delete(dose: Dose)

    @Query("DELETE FROM doses WHERE medicationId = :medId")
    suspend fun deleteDosesForMedication(medId: Long)

    /**
     * Returns all doses scheduled between [start] and [end] timestamps. When
     * [medId] is provided, filters by the medication ID; otherwise all
     * medications are included. Results are ordered by scheduled time.
     */
    @Query(
        "SELECT * FROM doses WHERE scheduledTime BETWEEN :start AND :end " +
                "AND (:medId IS NULL OR medicationId = :medId) ORDER BY scheduledTime ASC"
    )
    suspend fun getDosesInRange(start: Long, end: Long, medId: Long?): List<Dose>
}