package com.example.medtracker.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Base64
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.example.medtracker.data.AppDatabase
import com.example.medtracker.util.KeyManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.concurrent.Executor

/**
 * Entry activity that prompts the user to set a password on first launch or
 * authenticate on subsequent launches. The password serves as the basis
 * for deriving the encryption key and is never stored in plaintext. A salt
 * derived from the device's Android ID is used to generate the key【526260994498480†L257-L270】. On
 * devices with biometric support, the user may opt to unlock using a
 * fingerprint or face. In biometric mode, the derived AES key is stored in
 * encrypted preferences and retrieved after successful authentication so that
 * the user does not need to reenter their password.
 */
class MainActivity : ComponentActivity() {
    private lateinit var executor: Executor
    private lateinit var biometricPrompt: BiometricPrompt
    private lateinit var encryptedPrefs: EncryptedSharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Initialize encrypted preferences using a master key. This ensures
        // confidentiality and integrity for stored secrets.
        val masterKey = MasterKey.Builder(this)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
        encryptedPrefs = EncryptedSharedPreferences.create(
            this,
            "secure_prefs",
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )

        // Determine if a password hash exists; if not, prompt for setup
        val storedHash = encryptedPrefs.getString(KEY_HASH, null)
        if (storedHash == null) {
            showSetupView()
        } else {
            showLoginView()
        }
    }

    /**
     * Displays the password setup screen. The user must enter a non‑empty
     * password twice. The password is used to generate a random salt and derive
     * the encryption key. Both the salt and the derived key are stored in
     * encrypted preferences for later use. The password itself is not stored.
     */
    private fun showSetupView() {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 32, 32, 32)
        }
        val prompt = TextView(this).apply {
            text = "Create a password to encrypt your data"
        }
        val passwordField = EditText(this).apply {
            hint = "Password"
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        val confirmField = EditText(this).apply {
            hint = "Confirm Password"
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        val errorView = TextView(this).apply {
            visibility = View.GONE
            setTextColor(ContextCompat.getColor(context, android.R.color.holo_red_dark))
        }
        val button = Button(this).apply {
            text = "Set Password"
            setOnClickListener {
                val pwd1 = passwordField.text.toString()
                val pwd2 = confirmField.text.toString()
                if (pwd1.isBlank() || pwd2.isBlank()) {
                    errorView.text = "Password cannot be empty"
                    errorView.visibility = View.VISIBLE
                    return@setOnClickListener
                }
                if (pwd1 != pwd2) {
                    errorView.text = "Passwords do not match"
                    errorView.visibility = View.VISIBLE
                    return@setOnClickListener
                }
                // Derive salt using device Android ID. This salt may be reused
                // across password changes but remains unique per installation.
                val androidId = android.provider.Settings.Secure.getString(
                    contentResolver,
                    android.provider.Settings.Secure.ANDROID_ID
                )
                val saltBytes = androidId.toByteArray(Charsets.UTF_8)
                val hash = KeyManager.hashPassword(pwd1.toCharArray(), saltBytes)
                // Derive AES key from password for database encryption
                val secretKey = KeyManager.deriveKey(pwd1.toCharArray(), saltBytes)
                // Store Base64 encoded hash and derived key securely
                encryptedPrefs.edit().apply {
                    putString(KEY_SALT, Base64.encodeToString(saltBytes, Base64.NO_WRAP))
                    putString(KEY_HASH, hash)
                    putString(KEY_DB_KEY, Base64.encodeToString(secretKey.encoded, Base64.NO_WRAP))
                    apply()
                }
                // Clear the password fields for security
                passwordField.text.clear()
                confirmField.text.clear()
                // Launch the home screen after setup
                openHome(secretKey.encoded)
            }
        }
        layout.addView(prompt)
        layout.addView(passwordField)
        layout.addView(confirmField)
        layout.addView(errorView)
        layout.addView(button)
        setContentView(layout)
    }

    /**
     * Displays the login screen. The user enters their password to derive the
     * encryption key and unlock the database. Alternatively, if biometrics are
     * available and previously configured, the user can choose to authenticate
     * using their fingerprint or face and reuse the stored encryption key.
     */
    private fun showLoginView() {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 32, 32, 32)
        }
        val prompt = TextView(this).apply {
            text = "Enter your password"
        }
        val passwordField = EditText(this).apply {
            hint = "Password"
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        val errorView = TextView(this).apply {
            visibility = View.GONE
            setTextColor(ContextCompat.getColor(context, android.R.color.holo_red_dark))
        }
        val loginButton = Button(this).apply {
            text = "Unlock"
            setOnClickListener {
                val pwd = passwordField.text.toString()
                if (pwd.isBlank()) {
                    errorView.text = "Password cannot be empty"
                    errorView.visibility = View.VISIBLE
                    return@setOnClickListener
                }
                val saltBase64 = encryptedPrefs.getString(KEY_SALT, "")!!
                val storedHash = encryptedPrefs.getString(KEY_HASH, "")!!
                val saltBytes = Base64.decode(saltBase64, Base64.NO_WRAP)
                val inputHash = KeyManager.hashPassword(pwd.toCharArray(), saltBytes)
                if (secureCompare(storedHash, inputHash)) {
                    val secret = KeyManager.deriveKey(pwd.toCharArray(), saltBytes).encoded
                    passwordField.text.clear()
                    openHome(secret)
                } else {
                    errorView.text = "Invalid password"
                    errorView.visibility = View.VISIBLE
                }
            }
        }
        layout.addView(prompt)
        layout.addView(passwordField)
        layout.addView(errorView)
        layout.addView(loginButton)

        // Optional biometrics
        val biometricManager = BiometricManager.from(this)
        if (biometricManager.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG) ==
            BiometricManager.BIOMETRIC_SUCCESS
        ) {
            executor = ContextCompat.getMainExecutor(this)
            biometricPrompt = BiometricPrompt(this, executor, object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    // Retrieve stored DB key upon biometric success
                    val keyBase64 = encryptedPrefs.getString(KEY_DB_KEY, null)
                    if (keyBase64 != null) {
                        val secret = Base64.decode(keyBase64, Base64.NO_WRAP)
                        openHome(secret)
                    }
                }
                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    errorView.text = errString
                    errorView.visibility = View.VISIBLE
                }
            })
            val biometricButton = Button(this).apply {
                text = "Use Biometrics"
                setOnClickListener {
                    val promptInfo = BiometricPrompt.PromptInfo.Builder()
                        .setTitle("Biometric login")
                        .setSubtitle("Authenticate to access your medication data")
                        .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG)
                        .build()
                    biometricPrompt.authenticate(promptInfo)
                }
            }
            layout.addView(biometricButton)
        }
        setContentView(layout)
    }

    /**
     * Securely compares two strings in constant time to avoid timing attacks.
     */
    private fun secureCompare(a: String, b: String): Boolean {
        if (a.length != b.length) return false
        var result = 0
        for (i in a.indices) {
            result = result or (a[i].code xor b[i].code)
        }
        return result == 0
    }

    /**
     * Opens the home activity by initializing the encrypted database with
     * the derived key. This method must run on a background thread to avoid
     * blocking the UI.
     */
    private fun openHome(key: ByteArray) {
        CoroutineScope(Dispatchers.IO).launch {
            // Initialize the encrypted database to ensure the key is valid.
            AppDatabase.getInstance(applicationContext, key)
            // Launch HomeActivity on the main thread
            kotlinx.coroutines.withContext(Dispatchers.Main) {
                val intent = Intent(this@MainActivity, HomeActivity::class.java)
                intent.putExtra(HomeActivity.EXTRA_DB_KEY, key)
                startActivity(intent)
                finish()
            }
        }
    }

    companion object {
        private const val KEY_SALT = "salt"
        private const val KEY_HASH = "password_hash"
        private const val KEY_DB_KEY = "db_key"

        /**
         * Returns the application's encrypted shared preferences using the
         * configured master key. This helper is used by components outside
         * [MainActivity] (e.g. alarm receivers, settings) to access
         * persisted encryption metadata and settings without having to
         * replicate initialization logic. Caller must supply a context.
         */
        fun getSecurePrefs(context: Context): EncryptedSharedPreferences {
            val masterKey = MasterKey.Builder(context)
                .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                .build()
            return EncryptedSharedPreferences.create(
                context,
                "secure_prefs",
                masterKey,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
        }
    }
}