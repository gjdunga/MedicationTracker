package com.example.medtracker.data

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Repository orchestrates database operations and ensures that all
 * modifications are accompanied by corresponding log entries. The
 * repository exposes coroutine functions for write operations and flows
 * for reads. Using the I/O dispatcher offloads database work onto a
 * background thread, respecting Android best practices.
 */
class MedicationRepository(private val db: AppDatabase) {
    private val medDao = db.medicationDao()
    private val doseDao = db.doseDao()
    private val logDao = db.logDao()

    // Medication flows
    fun getMedications(): Flow<List<Medication>> = medDao.getAllMedications()
    fun searchMedications(pattern: String): Flow<List<Medication>> = medDao.searchMedications("%$pattern%")

    fun getDosesForMedication(medId: Long): Flow<List<Dose>> = doseDao.getDosesForMedication(medId)
    fun getDosesByStatus(status: DoseStatus): Flow<List<Dose>> = doseDao.getDosesByStatus(status)
    fun getLogs(): Flow<List<MedicationLog>> = logDao.getAllLogs()

    suspend fun addMedication(medication: Medication) = withContext(Dispatchers.IO) {
        val id = medDao.insert(medication)
        logDao.insertLog(
            MedicationLog(
                timestamp = System.currentTimeMillis(),
                type = LogType.MEDICATION_ADDED,
                medicationId = id,
                description = "Added medication '${medication.name}'"
            )
        )
    }

    suspend fun updateMedication(medication: Medication) = withContext(Dispatchers.IO) {
        medDao.update(medication)
        logDao.insertLog(
            MedicationLog(
                timestamp = System.currentTimeMillis(),
                type = LogType.MEDICATION_UPDATED,
                medicationId = medication.id,
                description = "Updated medication '${medication.name}'"
            )
        )
    }

    suspend fun deleteMedication(medication: Medication) = withContext(Dispatchers.IO) {
        medDao.delete(medication)
        logDao.insertLog(
            MedicationLog(
                timestamp = System.currentTimeMillis(),
                type = LogType.MEDICATION_DELETED,
                medicationId = medication.id,
                description = "Deleted medication '${medication.name}'"
            )
        )
    }

    suspend fun addDose(dose: Dose) = withContext(Dispatchers.IO) {
        val id = doseDao.insert(dose)
        logDao.insertLog(
            MedicationLog(
                timestamp = System.currentTimeMillis(),
                type = LogType.DOSE_ADDED,
                medicationId = dose.medicationId,
                doseId = id,
                description = "Added dose ${dose.amount}${dose.unit} for medicationId=${dose.medicationId} at ${dose.scheduledTime}"
            )
        )
    }

    /**
     * Inserts a [Dose] into the database and returns the generated ID. A
     * corresponding log entry of type [LogType.DOSE_ADDED] is also recorded.
     * This method can be used when the caller must know the ID immediately,
     * for example when scheduling an alarm. Avoids null references by
     * requiring a fully specified [Dose] instance with valid fields.
     */
    suspend fun addDoseAndReturnId(dose: Dose): Long = withContext(Dispatchers.IO) {
        val id = doseDao.insert(dose)
        logDao.insertLog(
            MedicationLog(
                timestamp = System.currentTimeMillis(),
                type = LogType.DOSE_ADDED,
                medicationId = dose.medicationId,
                doseId = id,
                description = "Added dose ${dose.amount}${dose.unit} for medicationId=${dose.medicationId} at ${dose.scheduledTime}"
            )
        )
        id
    }

    suspend fun updateDose(dose: Dose) = withContext(Dispatchers.IO) {
        doseDao.update(dose)
        logDao.insertLog(
            MedicationLog(
                timestamp = System.currentTimeMillis(),
                type = LogType.DOSE_UPDATED,
                medicationId = dose.medicationId,
                doseId = dose.id,
                description = "Updated dose ${dose.id} for medicationId=${dose.medicationId}"
            )
        )
    }

    suspend fun deleteDose(dose: Dose) = withContext(Dispatchers.IO) {
        doseDao.delete(dose)
        logDao.insertLog(
            MedicationLog(
                timestamp = System.currentTimeMillis(),
                type = LogType.DOSE_DELETED,
                medicationId = dose.medicationId,
                doseId = dose.id,
                description = "Deleted dose ${dose.id} for medicationId=${dose.medicationId}"
            )
        )
    }

    suspend fun markDoseTaken(doseId: Long, actualTime: Long = System.currentTimeMillis()) = withContext(Dispatchers.IO) {
        val dose = doseDao.getDoseById(doseId)
        val updated = dose.copy(status = DoseStatus.TAKEN, takenTime = actualTime)
        doseDao.update(updated)
        logDao.insertLog(
            MedicationLog(
                timestamp = System.currentTimeMillis(),
                type = LogType.DOSE_TAKEN,
                medicationId = updated.medicationId,
                doseId = updated.id,
                description = "Dose ${updated.id} taken at $actualTime"
            )
        )
    }

    suspend fun skipDose(doseId: Long) = withContext(Dispatchers.IO) {
        val dose = doseDao.getDoseById(doseId)
        val updated = dose.copy(status = DoseStatus.SKIPPED, takenTime = 0L)
        doseDao.update(updated)
        logDao.insertLog(
            MedicationLog(
                timestamp = System.currentTimeMillis(),
                type = LogType.DOSE_SKIPPED,
                medicationId = updated.medicationId,
                doseId = updated.id,
                description = "Dose ${updated.id} skipped"
            )
        )
    }

    suspend fun snoozeDose(doseId: Long, snoozeUntil: Long) = withContext(Dispatchers.IO) {
        val dose = doseDao.getDoseById(doseId)
        val updated = dose.copy(status = DoseStatus.SNOOZED, snoozedUntil = snoozeUntil)
        doseDao.update(updated)
        logDao.insertLog(
            MedicationLog(
                timestamp = System.currentTimeMillis(),
                type = LogType.DOSE_SNOOZED,
                medicationId = updated.medicationId,
                doseId = updated.id,
                description = "Dose ${updated.id} snoozed until $snoozeUntil"
            )
        )
    }

    suspend fun recordDatabaseReset() = withContext(Dispatchers.IO) {
        logDao.insertLog(
            MedicationLog(
                timestamp = System.currentTimeMillis(),
                type = LogType.DATABASE_RESET,
                description = "Database reset requested"
            )
        )
    }

    suspend fun recordPasswordChange() = withContext(Dispatchers.IO) {
        logDao.insertLog(
            MedicationLog(
                timestamp = System.currentTimeMillis(),
                type = LogType.PASSWORD_CHANGED,
                description = "Encryption password changed"
            )
        )
    }

    suspend fun recordImport() = withContext(Dispatchers.IO) {
        logDao.insertLog(
            MedicationLog(
                timestamp = System.currentTimeMillis(),
                type = LogType.IMPORT,
                description = "Data imported"
            )
        )
    }

    suspend fun recordExport() = withContext(Dispatchers.IO) {
        logDao.insertLog(
            MedicationLog(
                timestamp = System.currentTimeMillis(),
                type = LogType.EXPORT,
                description = "Data exported"
            )
        )
    }

    /**
     * Returns all doses scheduled between [start] and [end]. If [medId] is
     * provided, only doses belonging to that medication are returned.
     * Calling this function on the IO dispatcher avoids blocking the main
     * thread. Doses are sorted by scheduled time.
     */
    suspend fun getDosesBetween(start: Long, end: Long, medId: Long? = null): List<Dose> = withContext(Dispatchers.IO) {
        db.doseDao().getDosesInRange(start, end, medId)
    }
}