package com.example.medtracker.data

import androidx.room.TypeConverter

/**
 * Provides conversion methods for unsupported Room types. Room does not
 * automatically know how to persist enums, so we convert them to Strings
 * and back. We also provide conversions for Double and Long values where
 * necessary.
 */
class Converters {
    @TypeConverter
    fun fromDoseUnit(unit: DoseUnit): String = unit.name

    @TypeConverter
    fun toDoseUnit(value: String): DoseUnit = DoseUnit.valueOf(value)

    @TypeConverter
    fun fromDoseStatus(status: DoseStatus): String = status.name

    @TypeConverter
    fun toDoseStatus(value: String): DoseStatus = DoseStatus.valueOf(value)

    @TypeConverter
    fun fromLogType(type: LogType): String = type.name

    @TypeConverter
    fun toLogType(value: String): LogType = LogType.valueOf(value)
}