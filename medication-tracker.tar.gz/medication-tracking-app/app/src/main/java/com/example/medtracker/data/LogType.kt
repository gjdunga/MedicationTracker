package com.example.medtracker.data

/**
 * Enumerates the types of actions recorded in the audit log. Each entry
 * corresponds to a user action that affects medication or dose records.
 */
enum class LogType {
    MEDICATION_ADDED,
    MEDICATION_UPDATED,
    MEDICATION_DELETED,
    DOSE_ADDED,
    DOSE_UPDATED,
    DOSE_DELETED,
    DOSE_TAKEN,
    DOSE_SKIPPED,
    DOSE_SNOOZED,
    DATABASE_RESET,
    PASSWORD_CHANGED,
    IMPORT,
    EXPORT
}