package com.example.medtracker.data

/**
 * Represents the state of a scheduled dose. The states help the
 * application determine how to present alarms and reports without
 * resorting to nullable fields. A status of SCHEDULED means the dose is
 * pending, TAKEN indicates the user acknowledged and recorded the dose,
 * SKIPPED denotes that the user explicitly skipped the dose, and SNOOZED
 * represents a temporary postponement.
 */
enum class DoseStatus {
    SCHEDULED,
    TAKEN,
    SKIPPED,
    SNOOZED
}