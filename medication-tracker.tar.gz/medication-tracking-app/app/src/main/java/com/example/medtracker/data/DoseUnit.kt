package com.example.medtracker.data

/**
 * Units of measure supported by the application. The units follow the
 * International System of Units and can be selected by the user when
 * defining a dose. Each unit includes a multiplier relative to the gram
 * (the base unit) to support conversion and reporting.
 */
enum class DoseUnit(val multiplierToGrams: Double) {
    GRAM(1.0),
    MILLIGRAM(1e-3),
    MICROGRAM(1e-6);

    override fun toString(): String {
        return when (this) {
            GRAM -> "g"
            MILLIGRAM -> "mg"
            MICROGRAM -> "µg"
        }
    }
}