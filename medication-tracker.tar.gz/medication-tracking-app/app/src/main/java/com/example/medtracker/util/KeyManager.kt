package com.example.medtracker.util

import android.util.Base64
import java.security.SecureRandom
import javax.crypto.SecretKey
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/**
 * KeyManager centralizes cryptographic key generation logic. It exposes
 * functions to derive strong symmetric keys from user‑supplied passwords and
 * salts using the PBKDF2 key derivation function. PBKDF2 is recommended by
 * OWASP for password hashing because it uses a configurable iteration count
 * and incorporates a salt to thwart precomputed dictionary and rainbow
 * table attacks【526260994498480†L257-L270】. A salt should be unique and
 * randomly generated for each user; here we derive the salt from the
 * device's persistent Android ID and recommend storing it separately from
 * the hashed password.
 */
object KeyManager {

    private const val DEFAULT_ITERATIONS = 310_000 // OWASP recommended minimum
    private const val KEY_LENGTH_BITS = 256

    /**
     * Derives a symmetric AES key from the given password and salt. The
     * password is processed with PBKDF2 using HmacSHA256 and the specified
     * iteration count. The resulting key is 256 bits long, suitable for
     * AES‑256 encryption【672704742630283†L344-L369】.
     *
     * @param password The user's passphrase. Pass in a `CharArray` to allow
     * clearing the contents after use.
     * @param salt A unique salt; should not be reused between users【526260994498480†L257-L270】.
     * @param iterations The number of PBKDF2 iterations. Higher values
     * strengthen the derived key at the cost of CPU time【199016673121006†L466-L487】.
     * @return A SecretKey derived from the password and salt.
     */
    fun deriveKey(
        password: CharArray,
        salt: ByteArray,
        iterations: Int = DEFAULT_ITERATIONS,
        keyLength: Int = KEY_LENGTH_BITS
    ): SecretKey {
        // PBKDF2 specification recommending HmacSHA256
        val keySpec = PBEKeySpec(password, salt, iterations, keyLength)
        val factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
        val keyBytes = factory.generateSecret(keySpec).encoded
        // Zero out sensitive data from the PBEKeySpec to mitigate in‑memory exposure
        keySpec.clearPassword()
        return SecretKeySpec(keyBytes, "AES")
    }

    /**
     * Hashes a password for storage. The hash is derived using PBKDF2 and then
     * Base64‑encoded for safe persistence. The same salt must be supplied for
     * both hashing and key derivation.
     */
    fun hashPassword(password: CharArray, salt: ByteArray): String {
        val key = deriveKey(password, salt)
        val encoded = Base64.encodeToString(key.encoded, Base64.NO_WRAP)
        // Clear password after hashing
        password.fill('\u0000')
        return encoded
    }

    /**
     * Generates a random salt of the specified length using a secure random
     * number generator. Although salts are not secret【199016673121006†L466-L479】, they must be
     * unpredictable to ensure that derived keys are unique across users【526260994498480†L257-L270】.
     *
     * @param length Number of bytes for the salt (default is 16 bytes).
     */
    fun generateRandomSalt(length: Int = 16): ByteArray {
        val salt = ByteArray(length)
        SecureRandom().nextBytes(salt)
        return salt
    }
}