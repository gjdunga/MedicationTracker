package com.example.medtracker.alarms

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Build
import android.media.AudioManager
import android.media.RingtoneManager
import androidx.core.app.NotificationCompat
import com.example.medtracker.R
import com.example.medtracker.data.AppDatabase
import com.example.medtracker.data.DoseStatus
import com.example.medtracker.data.MedicationRepository
import com.example.medtracker.ui.HomeActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import android.util.Base64

/**
 * Receiver triggered by alarms scheduled for dose reminders. When invoked, it
 * constructs a notification that informs the user of the scheduled medication
 * and allows them to mark it as taken, skip it, or snooze the reminder.
 * Each action triggers a corresponding update to the database through the
 * repository. To maintain separation of concerns, the receiver creates a
 * coroutine scope for asynchronous operations.
 */
class DoseAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val doseId = intent.getLongExtra(EXTRA_DOSE_ID, -1L)
        val medName = intent.getStringExtra(EXTRA_MED_NAME) ?: "Medication"
        if (doseId <= 0) return

        // Build the notification channel lazily
        val channelId = "medication_reminders"
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(channelId, "Medication Reminders", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "Notifications reminding you to take medications"
                enableLights(true)
                lightColor = Color.GREEN
                enableVibration(true)
            }
            notificationManager.createNotificationChannel(channel)
        }

        // Create intents for actions
        val takenIntent = Intent(context, DoseActionReceiver::class.java).apply {
            action = ACTION_TAKEN
            putExtra(EXTRA_DOSE_ID, doseId)
        }
        val skipIntent = Intent(context, DoseActionReceiver::class.java).apply {
            action = ACTION_SKIP
            putExtra(EXTRA_DOSE_ID, doseId)
        }
        val snoozeIntent = Intent(context, DoseActionReceiver::class.java).apply {
            action = ACTION_SNOOZE
            putExtra(EXTRA_DOSE_ID, doseId)
        }
        val takenPending = PendingIntent.getBroadcast(context, doseId.toInt() + 1000, takenIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val skipPending = PendingIntent.getBroadcast(context, doseId.toInt() + 2000, skipIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val snoozePending = PendingIntent.getBroadcast(context, doseId.toInt() + 3000, snoozeIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

        // Intent to open app when notification clicked
        val contentIntent = Intent(context, HomeActivity::class.java)
        val contentPending = PendingIntent.getActivity(context, doseId.toInt(), contentIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

        // Retrieve user settings for alarm sound and volume
        val prefs = com.example.medtracker.ui.MainActivity.getSecurePrefs(context)
        val soundKey = prefs.getString("pref_alarm_sound", "default") ?: "default"
        val volumePercent = prefs.getInt("pref_alarm_volume", 70)
        val soundUri = when (soundKey) {
            "beep" -> android.media.RingtoneManager.getDefaultUri(android.media.RingtoneManager.TYPE_NOTIFICATION)
            "chime" -> android.media.RingtoneManager.getDefaultUri(android.media.RingtoneManager.TYPE_ALARM)
            else -> android.media.RingtoneManager.getDefaultUri(android.media.RingtoneManager.TYPE_NOTIFICATION)
        }
        // Set system alarm volume relative to user preference
        val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as android.media.AudioManager
        val maxVol = audioManager.getStreamMaxVolume(android.media.AudioManager.STREAM_ALARM)
        val level = (volumePercent / 100.0 * maxVol).toInt()
        audioManager.setStreamVolume(android.media.AudioManager.STREAM_ALARM, level, 0)
        val notification = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("Medication Reminder: $medName")
            .setContentText("It's time to take your dose.")
            .setSound(soundUri)
            .setContentIntent(contentPending)
            .setAutoCancel(true)
            .addAction(R.drawable.ic_taken, "Taken", takenPending)
            .addAction(R.drawable.ic_skip, "Skip", skipPending)
            .addAction(R.drawable.ic_snooze, "Snooze", snoozePending)
            .build()

        notificationManager.notify(doseId.toInt(), notification)
    }

    companion object {
        const val EXTRA_DOSE_ID = "extra_dose_id"
        const val EXTRA_MED_NAME = "extra_med_name"
        const val ACTION_TAKEN = "com.example.medtracker.action.TAKEN"
        const val ACTION_SKIP = "com.example.medtracker.action.SKIP"
        const val ACTION_SNOOZE = "com.example.medtracker.action.SNOOZE"
        const val ACTION_TRIGGER = "com.example.medtracker.action.TRIGGER"
    }
}

/**
 * Handles user interactions from the medication reminder notification. Each
 * action updates the corresponding dose record and logs the action. Snoozing
 * reschedules the alarm based on the user's configured snooze interval.
 */
class DoseActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action
        val doseId = intent.getLongExtra(DoseAlarmReceiver.EXTRA_DOSE_ID, -1L)
        if (doseId <= 0 || action == null) return
        // Retrieve the encryption key from the calling intent; for brevity
        // this example uses a singleton repository. In a real application,
        // dependency injection (e.g., Hilt) should be used instead.
        // Retrieve encryption key from EncryptedSharedPreferences used for the database.
        val securePrefs = com.example.medtracker.ui.MainActivity.getSecurePrefs(context)
        val keyBase64 = securePrefs.getString("db_key", null) ?: return
        val keyBytes = android.util.Base64.decode(keyBase64, android.util.Base64.NO_WRAP)
        val db = AppDatabase.getInstance(context, keyBytes)
        val repo = MedicationRepository(db)
        CoroutineScope(Dispatchers.IO).launch {
            when (action) {
                DoseAlarmReceiver.ACTION_TAKEN -> repo.markDoseTaken(doseId)
                DoseAlarmReceiver.ACTION_SKIP -> repo.skipDose(doseId)
                DoseAlarmReceiver.ACTION_SNOOZE -> {
                    // Obtain snooze duration from encrypted prefs; default to 10 minutes
                    val minutesString = securePrefs.getString("pref_snooze_minutes", "10") ?: "10"
                    val minutes = minutesString.toIntOrNull() ?: 10
                    val snoozeUntil = System.currentTimeMillis() + minutes * 60_000L
                    repo.snoozeDose(doseId, snoozeUntil)
                    // Reschedule the alarm using AlarmManager
                    scheduleSnoozedAlarm(context, doseId, snoozeUntil)
                }
            }
        }
    }

    private fun scheduleSnoozedAlarm(context: Context, doseId: Long, triggerAtMillis: Long) {
        val alarmMgr = context.getSystemService(Context.ALARM_SERVICE) as? android.app.AlarmManager ?: return
        val intent = Intent(context, DoseAlarmReceiver::class.java).apply {
            action = DoseAlarmReceiver.ACTION_TRIGGER
            putExtra(DoseAlarmReceiver.EXTRA_DOSE_ID, doseId)
        }
        val pending = PendingIntent.getBroadcast(
            context,
            doseId.toInt(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        alarmMgr.setExactAndAllowWhileIdle(android.app.AlarmManager.RTC_WAKEUP, triggerAtMillis, pending)
    }
}