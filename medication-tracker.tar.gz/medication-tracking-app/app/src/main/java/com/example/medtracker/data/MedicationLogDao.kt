package com.example.medtracker.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

/**
 * Data access object for [MedicationLog]. Logs are append‑only and never
 * updated or deleted, ensuring an immutable audit trail that satisfies
 * HIPAA's audit control requirements【593785142464909†L196-L203】.
 */
@Dao
interface MedicationLogDao {
    @Insert
    suspend fun insertLog(log: MedicationLog)

    @Query("SELECT * FROM logs ORDER BY timestamp DESC")
    fun getAllLogs(): Flow<List<MedicationLog>>

    @Query("SELECT * FROM logs WHERE type = :type ORDER BY timestamp DESC")
    fun getLogsByType(type: LogType): Flow<List<MedicationLog>>

    @Query("SELECT * FROM logs WHERE timestamp BETWEEN :from AND :to ORDER BY timestamp DESC")
    fun getLogsBetween(from: Long, to: Long): Flow<List<MedicationLog>>
}