package com.example.medtracker.data

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * Stores an immutable audit trail entry. Each log records the time an
 * action occurred, the type of action, and identifiers for the affected
 * medication or dose. The optional description allows storing a human‑
 * readable narrative for debugging or export. A medicationId or doseId
 * of zero indicates that the log entry is not associated with a specific
 * record. We intentionally avoid nullable fields to satisfy the strict
 * requirement against nulls.
 */
@Entity(
    tableName = "logs",
    foreignKeys = [
        ForeignKey(
            entity = Medication::class,
            parentColumns = ["id"],
            childColumns = ["medicationId"],
            onDelete = ForeignKey.CASCADE
        ),
        ForeignKey(
            entity = Dose::class,
            parentColumns = ["id"],
            childColumns = ["doseId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["medicationId"]), Index(value = ["doseId"])]
)
data class MedicationLog(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val timestamp: Long,
    val type: LogType,
    val medicationId: Long = 0L,
    val doseId: Long = 0L,
    val description: String = ""
)